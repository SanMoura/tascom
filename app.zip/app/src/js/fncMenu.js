
// abrir tela para novo usuario
$('#novoUsuario').click(function () {
  var newAba = '<li class="nav-item dropdown no-arrow mx-1" id="abaUsuarios">'
  +'<a class="nav-link dropdown-toggle text-dark">'
    +'<div class="card">'
      +'<div class="row align-items-center">'
        +'<div class="col mr-1">'
          +'<div class="text-xs font-weight-bold text-secondary text-uppercase aba">USUARIOS</div>'
        +'</div>'
        +'<div class="fechaAba"><i class="fas fa-times" id="fechaAbaUsuarios"></i></div>'
      +'</div>'
    +'</div>'
  +'</a>'
  +'</li>';
  jQuery.ajax({
    type: "POST",
    url: "src/usuarios/novo.html",
    data: {},
    success: function (data) {
      $("#navAbas").append(newAba);
      $("#paginas").html(data);
      $("#injectScripts").html("<script>$('#fechaAbaUsuarios').click(function(){$('#paginas').html(''); $('#abaUsuarios').html('');});</script>");
    }
  })
});

