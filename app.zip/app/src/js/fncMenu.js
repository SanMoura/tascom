
// abrir tela para novo usuario
$('#novoUsuario').click(function(){
  jQuery.ajax({
    type: "POST",
    url: "src/usuarios/novo.html",
    data: {},
    success: function (data) {
      $("#mainTela").html(data);
    }
})
});